package com.example.validate;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private TextView usernameValidationText, passwordStrengthText;
    private Button validateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        usernameValidationText = findViewById(R.id.usernameValidationText);
        passwordStrengthText = findViewById(R.id.passwordStrengthText);
        validateButton = findViewById(R.id.validateButton);

        // Real-time validation for Username
        usernameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No action needed before text changes
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().matches("^[A-Z][a-zA-Z]+$")) {
                    usernameValidationText.setText("Username is valid");
                    usernameValidationText.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                } else {
                    usernameValidationText.setText("Username should start with a capital letter and contain only letters");
                    usernameValidationText.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No action needed after text changes
            }
        });

        // Remove real-time validation for Password
        passwordEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No action needed before text changes
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // No action needed during text changes
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No action needed after text changes
            }
        });

        validateButton.setOnClickListener(view -> validateAndStoreLogin());
    }

    private void validateAndStoreLogin() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Validate Username
        if (!username.matches("^[A-Z][a-zA-Z]+$")) {
            usernameValidationText.setText("Username should start with a capital letter and contain only letters");
            usernameValidationText.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            return;
        }

        // Validate Password
        if (password.matches("^(?=.*[A-Z])(?=.*\\d)[A-Za-z\\d]{6,}$")) {
            if (password.length() >= 8) {
                passwordStrengthText.setText("valid passord");
                passwordStrengthText.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            } else {
                passwordStrengthText.setText("Medium Password");
                passwordStrengthText.setTextColor(getResources().getColor(android.R.color.holo_orange_dark));
            }
        } else {
            passwordStrengthText.setText("Weak Password");
            passwordStrengthText.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        }

        // Check if both username and password are valid
        if (usernameValidationText.getText().equals("Username is valid") &&
                passwordStrengthText.getText().equals("valid password")) {
            // Proceed with storing login details
            // Save login details and navigate to next screen
            Toast.makeText(this, "Login details saved successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please ensure username and password meet the requirements", Toast.LENGTH_SHORT).show();
        }
    }
}
