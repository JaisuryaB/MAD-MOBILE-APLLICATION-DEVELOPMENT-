package com.example.studentinfoapp;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText rollNumberEditText, nameEditText, addressEditText, fatherMobileEditText,
            motherMobileEditText, personalMobileEditText, sem1GpaEditText, sem2GpaEditText,
            sem3GpaEditText, sem4GpaEditText, cgpaEditText, govtOrManagementEditText,
            dayScholarOrHostelerEditText, communityEditText;

    private TextView studentInfoTextView;
    private Map<String, String> studentDataMap = new HashMap<>();
    private final String CSV_FILE_NAME = "data.csv";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rollNumberEditText = findViewById(R.id.rollNumberEditText);
        nameEditText = findViewById(R.id.nameEditText);
        addressEditText = findViewById(R.id.addressEditText);
        fatherMobileEditText = findViewById(R.id.fatherMobileEditText);
        motherMobileEditText = findViewById(R.id.motherMobileEditText);
        personalMobileEditText = findViewById(R.id.personalMobileEditText);
        sem1GpaEditText = findViewById(R.id.sem1GpaEditText);
        sem2GpaEditText = findViewById(R.id.sem2GpaEditText);
        sem3GpaEditText = findViewById(R.id.sem3GpaEditText);
        sem4GpaEditText = findViewById(R.id.sem4GpaEditText);
        cgpaEditText = findViewById(R.id.cgpaEditText);
        govtOrManagementEditText = findViewById(R.id.govtOrManagementEditText);
        dayScholarOrHostelerEditText = findViewById(R.id.dayScholarOrHostelerEditText);
        communityEditText = findViewById(R.id.communityEditText);

        studentInfoTextView = findViewById(R.id.studentInfoTextView);

        Button searchButton = findViewById(R.id.searchButton);
        Button deleteButton = findViewById(R.id.deleteButton);
        Button addButton = findViewById(R.id.addButton);

        loadCSVDataFromAssets();

        searchButton.setOnClickListener(v -> {
            String rollNo = rollNumberEditText.getText().toString().trim();
            if (studentDataMap.containsKey(rollNo)) {
                studentInfoTextView.setText(studentDataMap.get(rollNo));
            } else {
                studentInfoTextView.setText("Student not found!");
            }
        });

        deleteButton.setOnClickListener(v -> {
            String rollNo = rollNumberEditText.getText().toString().trim();
            if (studentDataMap.containsKey(rollNo)) {
                studentDataMap.remove(rollNo);
                studentInfoTextView.setText("Student record deleted!");
            } else {
                studentInfoTextView.setText("Student not found!");
            }
        });

        addButton.setOnClickListener(v -> {
            String rollNo = rollNumberEditText.getText().toString().trim();
            String name = nameEditText.getText().toString().trim();
            String address = addressEditText.getText().toString().trim();
            String fatherMobile = fatherMobileEditText.getText().toString().trim();
            String motherMobile = motherMobileEditText.getText().toString().trim();
            String personalMobile = personalMobileEditText.getText().toString().trim();
            String sem1Gpa = sem1GpaEditText.getText().toString().trim();
            String sem2Gpa = sem2GpaEditText.getText().toString().trim();
            String sem3Gpa = sem3GpaEditText.getText().toString().trim();
            String sem4Gpa = sem4GpaEditText.getText().toString().trim();
            String cgpa = cgpaEditText.getText().toString().trim();
            String govtOrManagement = govtOrManagementEditText.getText().toString().trim();
            String dayScholarOrHosteler = dayScholarOrHostelerEditText.getText().toString().trim();
            String community = communityEditText.getText().toString().trim();

            if (!rollNo.isEmpty() && !name.isEmpty()) {
                String studentInfo = "Name: " + name + "\n" +
                        "Address: " + address + "\n" +
                        "Father Mobile: " + fatherMobile + "\n" +
                        "Mother Mobile: " + motherMobile + "\n" +
                        "Personal Mobile: " + personalMobile + "\n" +
                        "Semester 1 GPA: " + sem1Gpa + "\n" +
                        "Semester 2 GPA: " + sem2Gpa + "\n" +
                        "Semester 3 GPA: " + sem3Gpa + "\n" +
                        "Semester 4 GPA: " + sem4Gpa + "\n" +
                        "CGPA: " + cgpa + "\n" +
                        "Govt or Management: " + govtOrManagement + "\n" +
                        "Day Scholar or Hosteler: " + dayScholarOrHosteler + "\n" +
                        "Community: " + community;

                studentDataMap.put(rollNo, studentInfo);
                appendDataToCSV(rollNo, name, address, fatherMobile, motherMobile, personalMobile,
                        sem1Gpa, sem2Gpa, sem3Gpa, sem4Gpa, cgpa, govtOrManagement, dayScholarOrHosteler, community);
                studentInfoTextView.setText("Student added successfully!");
            } else {
                studentInfoTextView.setText("Roll number and Name are required!");
            }
        });
    }

    private void loadCSVDataFromAssets() {
        try {
            InputStream inputStream = getAssets().open(CSV_FILE_NAME);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");

                if (data.length >= 14) {
                    String rollNumber = data[0];
                    String studentInfo = "Name: " + getSafeValue(data, 1) + "\n" +
                            "Address: " + getSafeValue(data, 2) + "\n" +
                            "Father Mobile: " + getSafeValue(data, 3) + "\n" +
                            "Mother Mobile: " + getSafeValue(data, 4) + "\n" +
                            "Personal Mobile: " + getSafeValue(data, 5) + "\n" +
                            "Semester 1 GPA: " + getSafeValue(data, 6) + "\n" +
                            "Semester 2 GPA: " + getSafeValue(data, 7) + "\n" +
                            "Semester 3 GPA: " + getSafeValue(data, 8) + "\n" +
                            "Semester 4 GPA: " + getSafeValue(data, 9) + "\n" +
                            "CGPA: " + getSafeValue(data, 10) + "\n" +
                            "Govt or Management: " + getSafeValue(data, 11) + "\n" +
                            "Day Scholar or Hosteler: " + getSafeValue(data, 12) + "\n" +
                            "Community: " + getSafeValue(data, 13);
                    studentDataMap.put(rollNumber, studentInfo);
                } else {
                    Log.e("CSV Parsing", "Invalid row in CSV: " + line);
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to load CSV data", Toast.LENGTH_LONG).show();
        }
    }

    private void appendDataToCSV(String rollNumber, String name, String address, String fatherMobile,
                                 String motherMobile, String personalMobile, String sem1Gpa,
                                 String sem2Gpa, String sem3Gpa, String sem4Gpa, String cgpa,
                                 String govtOrManagement, String dayScholarOrHosteler, String community) {
        try {
            FileOutputStream fos = openFileOutput(CSV_FILE_NAME, MODE_APPEND);
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fos));
            writer.write(rollNumber + "," + name + "," + address + "," + fatherMobile + "," + motherMobile + ","
                    + personalMobile + "," + sem1Gpa + "," + sem2Gpa + "," + sem3Gpa + "," + sem4Gpa + ","
                    + cgpa + "," + govtOrManagement + "," + dayScholarOrHosteler + "," + community);
            writer.newLine();
            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to save data", Toast.LENGTH_LONG).show();
        }
    }

    private String getSafeValue(String[] data, int index) {
        return index < data.length ? data[index] : "N/A";
    }
}
